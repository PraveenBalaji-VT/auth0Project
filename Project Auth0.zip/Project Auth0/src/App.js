import "./App.css";
import LoginButton from "./auth/LoginButton";
import LogoutButton from "./auth/LogoutButton";
import Profile from "./auth/Profile";
import { Auth0Provider } from "@auth0/auth0-react";
import {useSelector} from "react-redux";

function App() {
  const domainValue = useSelector(state => state.domain);
  const clientIdValue = useSelector(state => state.clientId);
  return (
    <Auth0Provider domain={domainValue} clientId={clientIdValue} redirectUri={window.location.origin}>
      <LoginButton></LoginButton>
      <Profile></Profile>
      <LogoutButton></LogoutButton>
    </Auth0Provider>
  );
}

export default App;
