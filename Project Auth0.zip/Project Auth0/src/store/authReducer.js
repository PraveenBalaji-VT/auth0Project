const initialState = {
  domain: "dev-ihxwj5i2m0qyfevb.us.auth0.com",
  clientId: "KsBGVZWMRehiCW3QSmTwD0ZgFWSE4iwK",
};

function authReducer(state = initialState, action) {
  switch (action.type) {
    case "DOMAIN":
      return { domain: state.domain };
    case "CLIENTID":
      return { clientId: state.clientId };
    default:
      return state;
  }
}

export default authReducer;
